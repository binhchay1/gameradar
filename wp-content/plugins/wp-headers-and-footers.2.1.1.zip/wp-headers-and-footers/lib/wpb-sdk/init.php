<?php
/**
 * WPBrigade SDK
 *
 * @package WPB_SDK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/includes/wpb-sdk-track.php';
require_once dirname( __FILE__ ) . '/includes/wpb-sdk-logger.php';
